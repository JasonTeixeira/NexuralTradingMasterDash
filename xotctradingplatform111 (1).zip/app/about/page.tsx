import AboutPageClient from "@/components/AboutPageClient"

export default function AboutPage() {
  return (
    <div className="min-h-screen">
      <AboutPageClient />
    </div>
  )
}
